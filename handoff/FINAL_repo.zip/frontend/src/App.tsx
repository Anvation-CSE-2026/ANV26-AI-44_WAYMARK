import { Suspense, lazy } from 'react'
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { Footer } from './components/Footer'
import { Nav } from './components/Nav'
import { LogoLoader } from './components/ui'

const MapPage = lazy(() => import('./pages/MapPage'))
const EvidencePage = lazy(() => import('./pages/EvidencePage'))
const DataQualityPage = lazy(() => import('./pages/DataQualityPage'))
const AuditListPage = lazy(() => import('./pages/AuditListPage'))
const AboutPage = lazy(() => import('./pages/AboutPage'))
const RegionPage = lazy(() => import('./pages/RegionPage'))

export default function App() {
  return (
    <AuthProvider>
    <BrowserRouter>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <div className="flex min-h-screen flex-col">
        <Nav />
        <main id="main" className="flex flex-1 flex-col">
          <Suspense
            fallback={
              <div className="flex flex-1 items-center justify-center py-24">
                <LogoLoader label="Loading" />
              </div>
            }
          >
            <Routes>
              <Route path="/" element={<MapPage />} />
              <Route path="/evidence" element={<EvidencePage />} />
              <Route path="/data-quality" element={<DataQualityPage />} />
              <Route path="/audit-list" element={<AuditListPage />} />
              <Route path="/about" element={<AboutPage />} />
              <Route path="/region/:regionId" element={<RegionPage />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Suspense>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
    </AuthProvider>
  )
}
