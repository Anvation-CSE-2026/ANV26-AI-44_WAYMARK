import { useState } from 'react'
import type { FormEvent, ReactNode } from 'react'
import { useAuth } from '../context/auth'
import { ROLE_LABELS } from '../lib/types.ops'
import type { RoleId } from '../lib/types.ops'
import { Card } from './ui'

const ROLE_BLURB: Record<RoleId, string> = {
  planner: 'Reviews evidence, approves or rejects, owns the plan.',
  engineer: 'Delivers measures and uploads before / after photos.',
  community: 'Proposes measures, comments and adds photos.',
}

/** Sign-in panel: one-click demo roles, plus a username and password form. */
export function SignIn() {
  const { demoLogin, login, busy, error } = useAuth()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const submit = (e: FormEvent) => {
    e.preventDefault()
    void login(username, password)
  }
  return (
    <Card className="mx-auto max-w-2xl p-5 md:p-6">
      <h2 className="font-serif text-2xl font-bold">Sign in to use reports, the assistant and the action plan</h2>
      <p className="mt-1 text-navy/75">Map browsing stays open to everyone. Pick a demo role, or use an account.</p>
      <div className="mt-4 grid gap-2 sm:grid-cols-3">
        {(Object.keys(ROLE_LABELS) as RoleId[]).map((r) => (
          <button
            key={r}
            type="button"
            disabled={busy}
            onClick={() => void demoLogin(r)}
            className="rounded-[12px] border border-navy/20 bg-white p-3 text-left hover:border-brass hover:bg-ivory-200/60 disabled:opacity-60"
          >
            <span className="block font-semibold">{ROLE_LABELS[r]}</span>
            <span className="mt-0.5 block text-sm text-navy/70">{ROLE_BLURB[r]}</span>
          </button>
        ))}
      </div>
      <form onSubmit={submit} className="mt-5 grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
        <label className="block text-sm font-semibold">
          Username
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            autoComplete="username"
            required
            className="mt-1 w-full rounded-lg border border-navy/25 px-3 py-2 font-normal"
          />
        </label>
        <label className="block text-sm font-semibold">
          Password
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
            required
            className="mt-1 w-full rounded-lg border border-navy/25 px-3 py-2 font-normal"
          />
        </label>
        <button
          type="submit"
          disabled={busy}
          className="rounded-lg bg-navy px-4 py-2 font-semibold text-ivory hover:bg-navy-800 disabled:opacity-60"
        >
          {busy ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
      <p aria-live="polite" role="status" className={`mt-3 min-h-6 text-sm font-semibold ${error ? 'text-brick' : ''}`}>
        {error}
      </p>
    </Card>
  )
}

/** Shows the sign-in panel instead of its children until someone is signed in. */
export function AuthGate({ children }: { children: ReactNode }) {
  const { user } = useAuth()
  return user ? <>{children}</> : <SignIn />
}
