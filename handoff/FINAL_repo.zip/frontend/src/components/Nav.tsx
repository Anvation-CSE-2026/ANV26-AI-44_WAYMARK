import { Link, NavLink } from 'react-router-dom'
import { useAuth } from '../context/auth'
import { ROLE_LABELS } from '../lib/types.ops'
import type { RoleId } from '../lib/types.ops'
import { Logo } from './Logo'

const links = [
  { to: '/', label: 'Map', end: true },
  { to: '/evidence', label: 'Evidence', end: false },
  { to: '/data-quality', label: 'Data quality', end: false },
  { to: '/audit-list', label: 'Audit list', end: false },
  { to: '/about', label: 'About', end: false },
]

const ROLES = Object.keys(ROLE_LABELS) as RoleId[]

function Account() {
  const { user, demoLogin, logout, busy } = useAuth()
  if (!user) {
    return <span className="shrink-0 text-sm text-ivory/70">Not signed in</span>
  }
  const isDemo = user.id.startsWith('demo-')
  return (
    <div className="flex shrink-0 items-center gap-2 border-l border-white/20 pl-3">
      <span
        data-testid="role-badge"
        className="rounded-full bg-brass px-2.5 py-0.5 text-sm font-bold text-navy"
        title={user.name}
      >
        <span className="sr-only">Signed in as </span>
        {user.role}
      </span>
      {isDemo && (
        <label className="hidden text-sm sm:block">
          <span className="sr-only">Switch demo role</span>
          <select
            value={user.role}
            disabled={busy}
            onChange={(e) => void demoLogin(e.target.value as RoleId)}
            className="rounded-md border border-white/30 bg-navy-800 px-2 py-1 text-sm text-ivory"
          >
            {ROLES.map((r) => (
              <option key={r} value={r}>
                {ROLE_LABELS[r]}
              </option>
            ))}
          </select>
        </label>
      )}
      <button
        type="button"
        onClick={logout}
        aria-label="Sign out"
        className="rounded-md px-2 py-1 text-sm text-ivory/85 hover:bg-white/10 hover:text-ivory"
      >
        <span aria-hidden="true" className="sm:hidden">✕</span>
        <span className="hidden sm:inline">Sign out</span>
      </button>
    </div>
  )
}

export function Nav() {
  return (
    <header className="sticky top-0 z-[1200] h-16 bg-navy text-ivory shadow-card">
      <div className="flex h-full w-full items-center gap-4 px-4">
        <Link to="/" aria-label="WAYMARK home" className="shrink-0">
          <Logo tone="dark" wordmarkClass="max-[420px]:hidden" />
        </Link>
        <nav aria-label="Primary" className="ml-auto flex min-w-0 gap-1 overflow-x-auto">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              className={({ isActive }) =>
                `whitespace-nowrap rounded-lg px-3 py-2 text-base font-medium transition-colors ${
                  isActive ? 'bg-brass text-navy' : 'text-ivory/85 hover:bg-white/10 hover:text-ivory'
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
        <Account />
      </div>
    </header>
  )
}
