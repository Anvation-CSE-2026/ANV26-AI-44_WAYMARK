import { useCallback, useEffect, useRef, useState } from 'react'
import type { DragEvent, FormEvent } from 'react'
import ReactMarkdown from 'react-markdown'
import { Link } from 'react-router-dom'
import { ApiError } from '../../lib/api'
import { opsApi } from '../../lib/opsApi'
import { ROLE_LABELS } from '../../lib/types.ops'
import type { ChatEvent, ChatSession, RecommendationCard, RegionReport, ReportChip, RoleId } from '../../lib/types.ops'
import { Card } from '../ui'
import { categoryLabel, fmtDate, useEffects } from '../ops/util'

const ROLE_INFO: Record<RoleId, { blurb: string; starters: string[] }> = {
  planner: {
    blurb: 'Priorities, sequencing and what evidence to require before approving.',
    starters: ['What should we do first?', 'Which cells should be audited before anything else?', 'What evidence should I ask for before approving a measure?'],
  },
  engineer: {
    blurb: 'Site inspections, deliverable measures and the photos to take.',
    starters: ['What should we inspect on site first?', 'Which measures can we deliver at the top hotspots?', 'What photos should I take as evidence?'],
  },
  community: {
    blurb: 'Plain-language meaning, what residents can report, what to raise.',
    starters: ['What does this report mean for our streets?', 'What can residents do to help?', 'What should we ask the planners to look at?'],
  },
}

interface UiMessage {
  key: string
  author: 'user' | 'assistant'
  content: string
  cards: RecommendationCard[]
  fallback: boolean
  streaming: boolean
  note?: string
  question?: string
}

type CardState = { state: 'idle' | 'adding' | 'added' | 'dismissed'; error?: string }

function Markdown({ text }: { text: string }) {
  return (
    <ReactMarkdown
      skipHtml
      components={{
        a: ({ href, children }) => (
          <a href={href} target="_blank" rel="noopener noreferrer" className="font-semibold text-teal underline">
            {children}
          </a>
        ),
        p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
        ul: ({ children }) => <ul className="mb-2 list-disc space-y-1 pl-5">{children}</ul>,
        ol: ({ children }) => <ol className="mb-2 list-decimal space-y-1 pl-5">{children}</ol>,
        code: ({ children }) => <code className="rounded bg-navy/10 px-1 font-mono text-sm">{children}</code>,
      }}
    >
      {text}
    </ReactMarkdown>
  )
}

export function AssistantTab({
  kind,
  regionKey,
  attachReport,
  onAddedToPlan,
}: {
  kind: string
  regionKey: string
  attachReport: RegionReport | null
  onAddedToPlan: (title: string) => void
}) {
  const fx = useEffects()
  const [session, setSession] = useState<ChatSession | null>(null)
  const [chip, setChip] = useState<ReportChip | null>(null)
  const [attachNote, setAttachNote] = useState<{ ok: boolean; text: string } | null>(null)
  const [attaching, setAttaching] = useState(false)
  const [dragging, setDragging] = useState(false)
  const [creating, setCreating] = useState<RoleId | null>(null)
  const [createError, setCreateError] = useState<string | null>(null)
  const [msgs, setMsgs] = useState<UiMessage[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [cards, setCards] = useState<Record<string, CardState>>({})
  const abortRef = useRef<AbortController | null>(null)
  const seq = useRef(0)
  const listRef = useRef<HTMLDivElement>(null)
  const lastAuto = useRef<string>('')

  const role = session?.role ?? null
  const anyFallback = msgs.some((m) => m.fallback)

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight })
  }, [msgs])

  const startSession = async (r: RoleId) => {
    abortRef.current?.abort()
    setCreating(r)
    setCreateError(null)
    try {
      const s = await opsApi.createSession(r)
      setSession(s)
      setChip(s.report)
      setMsgs([])
      setCards({})
      setAttachNote(null)
      lastAuto.current = ''
    } catch (e) {
      setCreateError(e instanceof ApiError ? e.message : 'Could not start a chat. Please try again.')
    } finally {
      setCreating(null)
    }
  }

  const attachFile = useCallback(
    async (file: Blob, name: string) => {
      if (!session) return
      setAttaching(true)
      setAttachNote(null)
      try {
        const c = await opsApi.attachReport(session.session_id, file, name)
        setChip(c)
        setAttachNote({ ok: true, text: `Attached ${c.report_id}.` })
      } catch (e) {
        setAttachNote({ ok: false, text: e instanceof ApiError ? e.message : 'That file could not be attached.' })
      } finally {
        setAttaching(false)
      }
    },
    [session],
  )

  // Hand-off from the Analysis tab: attach the report that was open there.
  useEffect(() => {
    if (!session || !attachReport) return
    const id = `${session.session_id}:${attachReport.report_id}`
    if (lastAuto.current === id || chip?.report_id === attachReport.report_id) return
    lastAuto.current = id
    ;(async () => {
      let blob: Blob
      try {
        blob = await opsApi.reportFile(attachReport.report_id, 'json')
      } catch {
        blob = new Blob([JSON.stringify(attachReport)], { type: 'application/json' })
      }
      await attachFile(blob, `${attachReport.report_id}.json`)
    })()
  }, [session, attachReport, chip, attachFile])

  const onDrop = (e: DragEvent) => {
    e.preventDefault()
    setDragging(false)
    const f = e.dataTransfer.files?.[0]
    if (f) void attachFile(f, f.name)
  }

  const latest = async () => {
    if (!session) return
    try {
      setChip(await opsApi.useLatestReport(session.session_id))
      setAttachNote({ ok: true, text: 'Now using the latest report.' })
    } catch (e) {
      setAttachNote({ ok: false, text: e instanceof ApiError ? e.message : 'Could not switch to the latest report.' })
    }
  }

  const patch = (key: string, fn: (m: UiMessage) => UiMessage) => setMsgs((all) => all.map((m) => (m.key === key ? fn(m) : m)))

  const send = async (text: string) => {
    const q = text.trim()
    if (!session || !q || busy) return
    const aKey = `a${++seq.current}`
    setMsgs((all) => [
      ...all,
      { key: `u${++seq.current}`, author: 'user', content: q, cards: [], fallback: false, streaming: false },
      { key: aKey, author: 'assistant', content: '', cards: [], fallback: false, streaming: true, question: q },
    ])
    setInput('')
    const ctrl = new AbortController()
    abortRef.current = ctrl
    setBusy(true)
    const onEvent = (ev: ChatEvent) => {
      if (ev.type === 'token') patch(aKey, (m) => ({ ...m, content: m.content + ev.text }))
      else if (ev.type === 'card') patch(aKey, (m) => ({ ...m, cards: [...m.cards, ev.card] }))
      else if (ev.type === 'done') patch(aKey, (m) => ({ ...m, fallback: ev.fallback_mode, streaming: false }))
      else if (ev.type === 'error') patch(aKey, (m) => ({ ...m, note: ev.message, streaming: false }))
    }
    try {
      await opsApi.sendMessage(session.session_id, q, onEvent, ctrl.signal)
    } catch (e) {
      const stopped = e instanceof DOMException && e.name === 'AbortError'
      patch(aKey, (m) => ({
        ...m,
        note: stopped ? 'Stopped.' : e instanceof ApiError ? e.message : 'The assistant could not answer. Please try again.',
      }))
    } finally {
      patch(aKey, (m) => ({ ...m, streaming: false }))
      setBusy(false)
      abortRef.current = null
    }
  }

  const submit = (e: FormEvent) => {
    e.preventDefault()
    void send(input)
  }

  const setCard = (id: string, s: CardState) => setCards((c) => ({ ...c, [id]: s }))

  const addToPlan = async (card: RecommendationCard) => {
    if (!chip) return
    setCard(card.card_id, { state: 'adding' })
    try {
      await opsApi.createMeasure({
        region_kind: chip.region.kind,
        region_key: chip.region.key,
        title: card.title,
        category: card.category,
        cell_ids: card.cell_ids,
        report_id: chip.report_id,
        description: card.rationale,
        owner_role: card.owner_role,
        source: 'chat',
      })
      setCard(card.card_id, { state: 'added' })
      onAddedToPlan(card.title)
    } catch (e) {
      setCard(card.card_id, { state: 'idle', error: e instanceof ApiError ? e.message : 'Could not add this to the plan.' })
    }
  }

  const otherRegion = chip && (chip.region.kind !== kind || chip.region.key !== regionKey)

  // ------------------------------------------------------------------ role selector
  if (!session) {
    return (
      <div className="space-y-4">
        <h2 className="font-serif text-2xl font-bold">Who is asking?</h2>
        <p className="max-w-3xl text-navy/80">
          Choose a role. It sets the assistant's tone and which measures it may propose. Then attach a Region Report and
          ask a question.
        </p>
        {attachReport && (
          <p role="note" className="rounded-lg bg-brass/15 px-3 py-2 font-semibold">
            Report {attachReport.report_id} is ready to attach once you pick a role.
          </p>
        )}
        <div role="group" aria-label="Choose a role" className="grid gap-3 md:grid-cols-3">
          {(Object.keys(ROLE_INFO) as RoleId[]).map((r) => (
            <button
              key={r}
              type="button"
              disabled={creating !== null}
              onClick={() => void startSession(r)}
              className="rounded-[12px] border-2 border-navy/15 bg-white p-4 text-left shadow-card hover:border-brass disabled:opacity-60"
            >
              <span className="block font-serif text-xl font-bold">{ROLE_LABELS[r]}</span>
              <span className="mt-1 block text-navy/75">{ROLE_INFO[r].blurb}</span>
              <span className="mt-3 block text-sm font-semibold text-teal">{creating === r ? 'Starting…' : 'Start as this role →'}</span>
            </button>
          ))}
        </div>
        {createError && <p role="alert" className="font-semibold text-brick">{createError}</p>}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <h2 className="font-serif text-2xl font-bold">Assistant</h2>
        <span className="rounded-full bg-navy px-3 py-0.5 text-sm font-semibold text-ivory">{role && ROLE_LABELS[role]}</span>
        <button type="button" onClick={() => setSession(null)} className="text-sm font-semibold text-teal underline-offset-2 hover:underline">
          Change role (starts a new chat)
        </button>
      </div>

      {/* ---------------------------------------------------------- report attach */}
      <Card className="p-4">
        <h3 className="font-semibold">Region report</h3>
        {chip ? (
          <div className="mt-2 space-y-2">
            <p>
              <span className="rounded-full border border-teal/50 bg-teal/10 px-2.5 py-0.5 font-mono text-sm text-teal">{chip.report_id}</span>{' '}
              <span className="ml-1">{chip.region.name}</span>
              <span className="ml-2 text-sm text-navy/65">generated {fmtDate(chip.generated_at)}</span>
            </p>
            {chip.stale && (
              <div role="alert" className="flex flex-wrap items-center gap-3 rounded-lg border border-amber/60 bg-amber/10 px-3 py-2 text-[#6b4210]">
                <span aria-hidden="true">⚠</span>
                <span className="flex-1">Out of date: {chip.stale_reason}</span>
                <button type="button" onClick={() => void latest()} className="rounded-md bg-navy px-3 py-1 text-sm font-semibold text-ivory hover:bg-navy-800">
                  Use latest report
                </button>
              </div>
            )}
            {otherRegion && (
              <p className="text-sm text-navy/75">
                This report is for another region. Measures you add go to{' '}
                <Link className="font-semibold text-teal underline" to={`/region/${encodeURIComponent(chip.region.key)}?kind=${encodeURIComponent(chip.region.kind)}&tab=progress`}>
                  {chip.region.name}
                </Link>
                .
              </p>
            )}
          </div>
        ) : (
          <p className="mt-1 text-navy/75">Attach a report so the assistant can suggest measures. Without one it cannot give recommendation cards.</p>
        )}
        <label
          onDragOver={(e) => {
            e.preventDefault()
            setDragging(true)
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
          className={`mt-3 flex cursor-pointer flex-col items-center gap-1 rounded-[12px] border-2 border-dashed px-4 py-5 text-center focus-within:outline focus-within:outline-[3px] focus-within:outline-brass ${
            dragging ? 'border-brass bg-brass/10' : 'border-navy/25 bg-ivory-200/50'
          }`}
        >
          <span className="font-semibold">{attaching ? 'Attaching…' : chip ? 'Drop another report here, or choose a file' : 'Drop the report PDF or JSON here, or choose a file'}</span>
          <span className="text-sm text-navy/65">PDF with the embedded data, a PDF showing a Report ID, or the JSON file</span>
          <input
            type="file"
            accept=".pdf,.json,application/pdf,application/json"
            className="sr-only"
            disabled={attaching}
            onChange={(e) => {
              const f = e.target.files?.[0]
              if (f) void attachFile(f, f.name)
              e.target.value = ''
            }}
          />
        </label>
        <p role="status" aria-live="polite" className={`mt-2 min-h-6 text-sm font-semibold ${attachNote && !attachNote.ok ? 'text-brick' : 'text-teal'}`}>
          {attachNote?.text}
        </p>
      </Card>

      {/* ---------------------------------------------------------- chat */}
      {anyFallback && (
        <div role="status" className="rounded-lg border border-amber/60 bg-amber/10 px-3 py-2 font-semibold text-[#6b4210]">
          AI assistant unavailable; showing rule-based suggestions
        </div>
      )}

      <Card className="flex flex-col">
        <div ref={listRef} aria-live="polite" aria-label="Conversation" role="log" className="max-h-[32rem] min-h-40 space-y-4 overflow-y-auto p-4">
          {msgs.length === 0 && (
            <div>
              <p className="text-navy/75">Ask a question about the attached report, or start with one of these:</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {role &&
                  ROLE_INFO[role].starters.map((s) => (
                    <button key={s} type="button" disabled={busy} onClick={() => void send(s)} className="rounded-full border border-navy/25 bg-white px-3 py-1.5 text-sm font-semibold hover:bg-ivory-200">
                      {s}
                    </button>
                  ))}
              </div>
            </div>
          )}
          {msgs.map((m) => (
            <div key={m.key} className={m.author === 'user' ? 'flex justify-end' : ''}>
              <div className={`max-w-[48rem] rounded-[12px] px-4 py-3 ${m.author === 'user' ? 'bg-navy text-ivory' : 'bg-ivory-200/70'}`}>
                <p className="sr-only">{m.author === 'user' ? 'You said' : 'Assistant said'}</p>
                {m.author === 'assistant' && m.content === '' && m.streaming ? (
                  <p className="text-navy/70">Thinking…</p>
                ) : m.author === 'assistant' ? (
                  <Markdown text={m.content} />
                ) : (
                  <p className="whitespace-pre-wrap">{m.content}</p>
                )}
                {m.note && (
                  <p className="mt-1 flex flex-wrap items-center gap-2 text-sm font-semibold text-brick">
                    {m.note}
                    {m.question && !busy && (
                      <button type="button" onClick={() => void send(m.question ?? '')} className="rounded-md border border-brick/50 bg-white px-2 py-0.5 text-brick hover:bg-brick/10">
                        Retry
                      </button>
                    )}
                  </p>
                )}
                {m.cards.length > 0 && (
                  <ul className="mt-3 space-y-3">
                    {m.cards.map((c) => {
                      const st = cards[c.card_id] ?? { state: 'idle' as const }
                      if (st.state === 'dismissed') return null
                      return (
                        <li key={c.card_id}>
                          <article aria-label={`Recommendation: ${c.title}`} className="rounded-[12px] border border-navy/15 bg-white p-4 text-navy">
                            <h4 className="font-semibold">{c.title}</h4>
                            <p className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-sm text-navy/75">
                              <span>Category: <strong>{categoryLabel(fx, c.category)}</strong></span>
                              <span>Owner: <strong>{ROLE_LABELS[c.owner_role]}</strong></span>
                              {c.evidence_needed.length > 0 && <span>Evidence: {c.evidence_needed.join(' + ')} photos</span>}
                            </p>
                            <p className="mt-2">{c.rationale}</p>
                            <p className="mt-2 text-sm text-navy/70">
                              Cells:{' '}
                              {c.cell_ids.map((id, i) => (
                                <span key={id}>
                                  {i > 0 && ', '}
                                  <Link to={`/?cell=${encodeURIComponent(id)}`} className="font-mono text-teal underline-offset-2 hover:underline">{id}</Link>
                                </span>
                              ))}
                            </p>
                            <div className="mt-3 flex flex-wrap items-center gap-2">
                              {st.state === 'added' ? (
                                <span className="inline-flex items-center gap-1.5 rounded-full border border-teal bg-teal px-3 py-1 text-sm font-semibold text-white">
                                  <span aria-hidden="true">✓</span>In plan
                                </span>
                              ) : (
                                <>
                                  <button
                                    type="button"
                                    disabled={st.state === 'adding' || !chip}
                                    onClick={() => void addToPlan(c)}
                                    className="rounded-lg bg-navy px-3 py-1.5 text-sm font-semibold text-ivory hover:bg-navy-800 disabled:opacity-60"
                                  >
                                    {st.state === 'adding' ? 'Adding…' : 'Add to action plan'}
                                  </button>
                                  <button type="button" onClick={() => setCard(c.card_id, { state: 'dismissed' })} className="rounded-lg border border-navy/25 px-3 py-1.5 text-sm font-semibold hover:bg-ivory-200">
                                    Dismiss
                                  </button>
                                </>
                              )}
                              {st.error && <span role="alert" className="text-sm font-semibold text-brick">{st.error}</span>}
                            </div>
                          </article>
                        </li>
                      )
                    })}
                  </ul>
                )}
              </div>
            </div>
          ))}
        </div>
        <form onSubmit={submit} className="flex flex-wrap items-end gap-2 border-t border-navy/10 p-3">
          <label className="min-w-0 flex-1 text-sm font-semibold">
            <span className="sr-only">Your question</span>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  void send(input)
                }
              }}
              rows={2}
              maxLength={4000}
              placeholder={chip ? 'Ask about this report…' : 'Attach a report first, then ask…'}
              className="w-full resize-y rounded-lg border border-navy/25 px-3 py-2 font-normal"
            />
          </label>
          {busy ? (
            <button type="button" onClick={() => abortRef.current?.abort()} className="rounded-lg border border-brick/60 px-4 py-2 font-semibold text-brick hover:bg-brick/10">
              Stop
            </button>
          ) : (
            <button type="submit" disabled={!input.trim()} className="rounded-lg bg-navy px-5 py-2 font-semibold text-ivory hover:bg-navy-800 disabled:opacity-50">
              Send
            </button>
          )}
        </form>
      </Card>

      <p className="text-sm text-navy/70">
        Suggestions are estimates for discussion, not engineering or legal advice. Check numbers against the report.
      </p>
    </div>
  )
}
