# WAYMARK frontend

Explainable road risk, cell by cell. React + Vite + TypeScript + Tailwind v4, Leaflet, h3-js (OpenStreetMap tiles by default, MapTiler optional), Recharts, React Router.

## Run it

Backend first (from the project root, venv active):

```bash
uvicorn backend.main:app --reload          # http://127.0.0.1:8000  (docs at /docs)
```

Then the frontend (second terminal):

```bash
cd frontend
npm install
npm run dev                                # http://localhost:5173
```

In dev, Vite proxies `/api/*` to `http://127.0.0.1:8000`, so no CORS setup is needed.

## Build and deploy

```bash
npm run build        # type-check + production bundle in dist/
npm run preview      # serve dist/ locally on :4173 (also proxies /api)
```

- Serve `dist/` from any static host (Netlify, Vercel, Cloudflare Pages, nginx).
- Set `VITE_API_BASE=https://your-api-host` **before** `npm run build` so the bundle calls your deployed backend (the backend already enables CORS).
- The app uses client-side routing: configure a fallback to `index.html` for unknown paths (Netlify: `/* /index.html 200`; nginx: `try_files $uri /index.html;`).

See `.env.example` for all variables.

## Pages

| Route | What it shows |
| --- | --- |
| `/` | Map: canvas-rendered cells, filters, side panel with SHAP chart, what-if toggles, guided demo |
| `/evidence` | Backtest: overall result, low-history bar chart, robustness (N=2/3/5, second split), bootstrap intervals, caveat |
| `/data-quality` | Every PASS/WARN/FAIL check, crashes per year (2017 and 2023 highlighted), crashes per month |
| `/audit-list` | Sortable, searchable, paged table of emerging-risk cells with CSV download |
| `/about` | Method, how to read the map, limits, data credit |

Deep link to a cell: `/?cell=89446ca89d7ffff`.

## API contract the UI expects

`src/lib/api.ts` normalises every response in one place. It accepts either a bare array or an object wrapping the list (`items`, `cells`, ...), and percentiles as 0–100 or 0–1. If a field name differs from your backend, adjust the matching `to*` function there.

| Endpoint | Fields used |
| --- | --- |
| `GET /api/summary` | `cells_scored`, `low_history_cells`, `emerging_risk_cells` |
| `GET /api/cells?limit=` | `cell_id, lat, lng, n_past_crashes, risk_score, risk_vs_similar_history, history_percentile, confidence, emerging_risk` |
| `GET /api/cells/{id}` | the above plus `top_factors`, `recommendations`, `confidence_explanation`, `google_maps_url`, `baseline_prob`, `shap[] {feature, feature_value, shap_value, rank}` |
| `GET /api/whatif?night=&rain=&low_vis=` | `cells[] {cell_id, baseline_prob, scenario_prob}` |
| `GET /api/validation` | `checks[] {check_name, status, detail}`, `yearly_counts[] {year, month, crashes}` |
| `GET /api/metrics` | rows of `{group_name, metric_name, model_value, history_value, extra_json}` |
| `GET /api/audit-list` (`?format=csv`) | emerging-risk cells, in display order |

The map requests `/api/cells?limit=20000` and falls back to 5000, then to no limit, if the backend rejects the value (HTTP 422).

## Behaviour notes

- Wording: "elevated risk" and "recommend a site audit" only; the what-if panel is labelled "Scenario simulation, not a live forecast"; a lower scenario probability is reported neutrally.
- Map: H3 hexagons coloured green (lower) → yellow → red (higher) by risk score (0-100). Zoomed out, cells are grouped into larger hexagons (mean score); zoomed in, every cell is drawn; from zoom 15 the real crash locations from your dataset appear as small points (`GET /api/crashes?bbox=`; run `pipeline/load_crashes.py` once to fill the `crashes` table, otherwise cell-centre dots are shown instead). A dark outline marks emerging-risk cells. The legend switches colouring to "Emerging risk" (history percentile; other cells grey). With a what-if scenario on, colours show the change from baseline instead (teal lower, grey same, yellow to brick higher). Click a grouped hexagon to open that region: the map flies there, that region's cells stay vivid and every other cell and crash point keeps its colour at lower opacity (clicking a single cell leaves region view and highlights only that cell; "Show all regions" or Esc to leave). A Hexagon opacity slider in the legend lets you see the streets underneath. With a MapTiler key, a Street / Satellite switch appears at the top of the map (your choice is remembered in the browser). Hexagon outlines come from `h3-js`.
- Scenario averages ("all cells", "emerging-risk cells") are computed from the per-cell baseline and scenario probabilities returned by `/api/whatif`.
- Evidence rows are grouped by matching words in `group_name` (overall, low history, robustness / N=2,3,5, split, bootstrap). Anything unmatched still appears in the "All stored metric rows" table.
- Keyboard: skip link, visible focus rings, switch/checkbox semantics, `Esc` closes the panel or demo, arrow keys step through the demo. Map markers themselves are not focusable, so use "Go to cell ID" or the Audit list.

## Demo checklist

1. Backend running, `/api/health` returns 200, `waymark.db` loaded.
2. Open the map: cells appear, summary chips show counts, no error banner.
3. Press **Start demo**: step through `89446ca89d7ffff`, `89446c32397ffff`, `89446ca125bffff`. At each: headline, confidence badge, "Elevated risk, recommend a site audit" banner, SHAP chart.
4. Turn on **Night**, then **Rain**, then **Low visibility**: map recolours, averages update, the selected cell shows baseline vs scenario.
5. Filters: Confidence = Low, drag **Max past crashes** down, tick **Emerging-risk cells only**.
6. **Evidence**: say the overall tie plainly, then the low-history chart, robustness table and the caveat box.
7. **Data quality**: point at the WARN badges and the 2017 and 2023 bars.
8. **Audit list**: sort by past crashes, search a cell ID, download the CSV.
9. Check on the projector: text legible from the back, footer line visible.

## Base map and API keys

The hexagons, crash points and scores come from your own backend and database and need no key. Only the base map tiles (streets) come from a tile provider.

- **Default: OpenStreetMap**, no key, nothing to set. Good for development and a demo; for heavy public traffic use a hosted provider (see the OSM tile usage policy).
- **MapTiler (optional):** create a free account at https://cloud.maptiler.com, copy your API key, then in `frontend/.env.local` set `VITE_TILE_PROVIDER=maptiler` and `VITE_TILE_KEY=<your key>`, and restart `npm run dev`. This adds the Street / Satellite switch. Free plans have monthly limits; a key used in a browser app is visible to users, so restrict it to your domain in the MapTiler dashboard before deploying.
