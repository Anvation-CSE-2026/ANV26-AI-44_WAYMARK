WAYMARK - evidence-backed suggestions patch

NEW files (copy into your project, same paths):
  pipeline/__init__.py, pipeline/advice.py, pipeline/rebuild_advice.py, backend/tests/test_advice.py
MODIFIED files (full copies included; modified_files.diff shows exactly what changed - apply it
if you have edited these files locally):
  blackspot_pipeline.py, frontend/src/components/map/DetailPanel.tsx

Then, from the project root:
  python pipeline/rebuild_advice.py        # updates waymark.db in place (backup: waymark.db.before_advice)
  python -m pytest                          # 22 tests

The script keeps your crashes table (do not use load_db.py for this, it deletes the whole file).
Safe to re-run. Restart the backend afterwards.
