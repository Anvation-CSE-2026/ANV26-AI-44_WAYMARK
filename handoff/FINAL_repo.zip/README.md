# WAYMARK

Explainable road risk, cell by cell, for the Harris County (Houston) area, plus an **action loop**:

1. **Analyse a region** and get a **Region Report** (on screen, PDF, JSON).
2. **Ask an assistant** (planner, engineer or community role) about the report and get **recommendation cards**.
3. **Track measures** through *planned → in progress → evidence submitted → verified*, with **photo evidence** and a **human review**.
4. See an **adjusted risk estimate** that gives credit **only for verified measures**.

WAYMARK is decision support only. Human experts decide. Risk numbers are estimates from historical crash records, not predictions.

---

## 1. Set up on a new computer

You need **Python 3.11+** and **Node.js 20+** (npm 10+). Git is optional.

Copy the whole project folder (it includes `waymark.db`, about 40 MB, which holds the scored cells and crash records). Then, from the project root:

**Windows (PowerShell)**
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
cd frontend
npm install
cd ..
```

**macOS / Linux**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cd frontend && npm install && cd ..
```

`requirements.txt` also lists the modelling libraries (lightgbm, shap, ...) used by `pipeline/`. If you only want to run the app and its tests, this smaller set is enough:
`pip install numpy pandas h3 sqlalchemy fastapi uvicorn pydantic httpx pytest matplotlib pyjwt python-multipart pillow reportlab pypdf anthropic`

## 2. Run it

Open two terminals in the project root (activate the virtual environment in the first).

**Terminal 1: the API (port 8000)**
```
uvicorn backend.main:app --reload
```
API docs: <http://127.0.0.1:8000/docs>. On first start the new tables (reports, measures, evidence, chat, risk snapshots) are added to `waymark.db`; existing tables are never touched.

**Terminal 2: the website (port 5173)**
```
cd frontend
npm run dev
```
Open <http://localhost:5173>. The dev server forwards `/api` to the backend, so no CORS set-up is needed.

**One-command alternative (no Node at run time):** `cd frontend && npm run build`, then just run `uvicorn backend.main:app`. The backend serves `frontend/dist` itself at <http://127.0.0.1:8000>.

### Try the whole flow (about 5 minutes)

1. Open the map, click a cell, then **Generate analysis report** in the *Region report* card (or click a grouped hexagon to open a bigger region first).
2. Choose **Planner / reviewer** under *Sign in*. The **planner** badge appears in the top bar.
3. **Analysis** tab → *Generate analysis report*. In about a second you get stat cards, hotspot table, two charts, priority issues, caveats, and PDF / JSON downloads.
4. **Ask the assistant** → pick a role → the report is already attached → ask *What should we do first?* With no API key you get the **rule-based fallback** banner and cards.
5. **Add to action plan** on a card. Use **+ Add measure manually** with *Street lighting and reflective signage* if you want a measure that actually changes the adjusted index (site safety audits have weight 0).
6. Switch role to **engineer** (top-bar menu). Open the measure, **Start work**, upload a *before* and an *after* photo. The status moves to *Evidence submitted*; the **Implementation** bar moves; the **Verified** bar and the adjusted index do not.
7. Sign in as a **planner who did not create or upload anything for that measure** and **Approve** (or **Reject** with a reason). Now the **Verified** bar and the **adjusted index** change.
8. Back on the map choose **Adjusted risk (estimate)**: measure markers (◆) appear, and the cell panel shows *Measures in this cell*.

> **Self-verification is blocked.** Nobody can review a measure they created or whose photos they uploaded. The demo buttons give the account `demo-planner`, so if you add a measure as the demo planner you must approve it as someone else, for example the real **planner** login below, or create the measure as engineer / community.

### Demo accounts

| Role | Username | Password | Can |
|---|---|---|---|
| planner | `planner` | `waymark-planner` | review (approve / reject), plus everything an engineer can do |
| engineer | `engineer` | `waymark-engineer` | move measures along, upload photos |
| community | `community` | `waymark-community` | propose measures, comment, upload photos |

`POST /api/auth/demo` with `{"role": "planner"}` returns a token for `demo-planner` without a password (switch off with `WAYMARK_DEMO_MODE=0`). Accounts live in `backend/config/demo_users.json` (PBKDF2 hashes); make a new hash with `python -m backend.auth hash <password>`. These are **demo accounts**: change them before any real deployment.

## 3. Settings (environment variables)

Everything has a default, so no `.env` file is needed. Set variables in the shell that starts `uvicorn`.

| Variable | Default | Meaning |
|---|---|---|
| `WAYMARK_JWT_SECRET` | random per start (warning logged) | Token signing key. Set it so logins survive a restart. |
| `WAYMARK_JWT_TTL_MIN` | `480` | Token lifetime in minutes |
| `WAYMARK_DEMO_MODE` | `1` | Allows `POST /api/auth/demo` |
| `WAYMARK_DATA_DIR` | `data` | Where evidence photos and report PDFs are stored |
| `WAYMARK_CORS_ORIGINS` | `http://localhost:5173,http://127.0.0.1:5173` | Comma list of allowed browser origins |
| `WAYMARK_MAX_UPLOAD_MB` | `10` | Evidence photo size cap |
| `WAYMARK_UPLOAD_RATE_PER_MIN` | `10` | Uploads per user per minute |
| `WAYMARK_MAX_REPORT_CELLS` | `5000` | Largest region a report may cover |
| `WAYMARK_GEO_FAR_KM` | `1.0` | A photo's GPS further than this from the measure's cells is flagged "far" |
| `WAYMARK_STALE_PHOTO_DAYS` | `30` | Photos older than this get an "old photo" flag |
| `ANTHROPIC_API_KEY` | unset | Unset = the assistant uses the rule-based fallback |
| `ANTHROPIC_MODEL` | `claude-sonnet-5-5` | Assistant model |
| `WAYMARK_CHAT_MAX_TOKENS` | `1500` | Max tokens per reply |
| `WAYMARK_DB` | `waymark.db` in the project root | Database file (existing setting) |

Frontend (`frontend/.env.local`, see `frontend/.env.example`): `VITE_API_BASE` (leave empty in dev), `VITE_USE_MOCKS=1` (run the reports / assistant / progress screens from in-memory fixtures with no backend; the map still needs the API), plus the existing map tile settings.

Example (Windows PowerShell), with the real assistant:
```powershell
$env:WAYMARK_JWT_SECRET = "a-long-random-string"
$env:ANTHROPIC_API_KEY  = "sk-ant-..."
uvicorn backend.main:app --reload
```

## 4. The risk overlay, in plain words

* Each measure has a category (`backend/config/effects.json`) with an **effect weight** `w`. The weight is **copied into the measure when it is created**, so editing the file later never rewrites history.
* A cell's **credit** comes **only from verified measures**: `credit = 1 − Π(1 − wᵢ)` over the verified measures touching that cell (**multiplicative**, so two 10% measures give 19%, not 20%), then **capped** at `credit_cap` (60%).
* **Adjusted score = base score × (1 − credit)**, never below 0 and never above the base score. The region's adjusted index is the mean of its cells' adjusted scores, the same aggregation as the base index.
* **Uploading photos never changes the adjusted index.** It only moves the *Implementation* bar (planned 0%, in progress 25%, evidence submitted 75%, verified 100%). Only a planner's approval moves the *Verified mitigation* bar and the adjusted index.
* This is an **overlay estimate, not a re-run of the model**. Cancelled measures are excluded from both percentages.

### Placeholder weights: read this

**Every weight and stage factor in `backend/config/effects.json` is a placeholder**, not a statistic. The file says `"placeholder": true`, and the UI, the PDF and this README show a warning while that flag is true. A domain owner must replace the values (and set the flags to `false`) before anyone relies on the adjusted numbers. The app refuses to start if the file is malformed and names the key that is wrong.

## 5. Tests and builds

```
python -m pytest                 # backend: 22 original tests + the operations tests, no network, Anthropic always mocked
cd frontend
npx tsc -b                       # type check
npx oxlint                       # lint (one old warning in MapLayers.tsx is from before this build)
npm run build                    # refreshes frontend/dist
```

## 6. Important warnings

* **`python pipeline/load_db.py --force` deletes the whole database file**, including crash records, **measures, evidence rows, reports and chat history**. Without `--force` it now refuses to run when `waymark.db` exists. To refresh only the suggested actions use `python pipeline/rebuild_advice.py`.
* Evidence photos and report PDFs live in `data/` (git-ignored). Back it up together with `waymark.db`.
* Uploaded photos are **re-encoded** (metadata and any hidden payload are removed) and stored under random names. The browser only downscales photos larger than 8 MB, because redrawing a picture in the browser would also erase the location and time the server uses for its "taken near the cells" check.

## 7. What is where

| Path | What |
|---|---|
| `backend/` | FastAPI app. New: `auth.py`, `permissions.py`, `config.py`, `config_loader.py`, `regions.py`, `reports/builder.py`, `risk_overlay.py`, `measures_service.py`, `evidence_service.py`, `playbooks.py`, `llm.py`, `models_ops.py`, `schemas_ops.py`, `routes/{auth,regions,reports,measures,evidence,chat}.py` |
| `backend/config/` | `effects.json` (categories, placeholder weights, cap), `demo_users.json` |
| `frontend/src/pages/RegionPage.tsx` | Region page with the Analysis / Assistant / Progress tabs (`components/region/*`) |
| `frontend/src/lib/mocks/` | Fixtures and mock router for `VITE_USE_MOCKS=1` |
| `contracts/` | `openapi_stub.json` (the API document), `sample_report.json` (a real report). Refresh with `python pipeline/make_contracts.py` |
| `handoff/` | `FINAL_report.md` (what works, what was cut, deviations), `samples/sample_report.pdf` |
| `README.txt` | Notes for the earlier "evidence-backed suggestions" patch |

Data: US Accidents (2016–2023), a countrywide traffic accident dataset by Sobhan Moosavi et al.
