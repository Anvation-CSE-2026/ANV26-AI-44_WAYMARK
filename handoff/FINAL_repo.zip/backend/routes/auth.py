from fastapi import APIRouter, HTTPException

from ..auth import ROLE_LABELS, Role, User, authenticate, create_token
from ..config import settings
from ..schemas_ops import DemoIn, LoginIn, TokenOut, UserOut

router = APIRouter(prefix="/api", tags=["auth"])


def _token_out(user: User) -> TokenOut:
    return TokenOut(access_token=create_token(user), user=UserOut(id=user.id, name=user.name, role=user.role))


@router.post("/auth/login", response_model=TokenOut)
def login(body: LoginIn):
    user = authenticate(body.username, body.password)
    if user is None:
        raise HTTPException(401, "Wrong username or password.")
    return _token_out(user)


@router.post("/auth/demo", response_model=TokenOut)
def demo(body: DemoIn):
    """Demo-mode sign-in: a token for the chosen role. Switched off with WAYMARK_DEMO_MODE=0."""
    if not settings.demo_mode:
        raise HTTPException(404, "Demo sign-in is turned off on this server.")
    role: Role = body.role
    return _token_out(User(id=f"demo-{role.value}", name=f"Demo {ROLE_LABELS[role]}", role=role))
